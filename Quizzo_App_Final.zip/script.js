        // Enable strict mode for better error detection
        'use strict';
        
        // Log that script is loading
        console.log('Physics Wayground: Script loading...');
        
        // Global error handler
        window.addEventListener('error', function(e) {
            console.error('Global error:', e.error);
            // Show error to user in development
            const mainContent = document.getElementById('mainContent');
            if (mainContent && !mainContent.innerHTML) {
                mainContent.innerHTML = '<div style="padding: 20px; background: #fee; border: 2px solid #c00; border-radius: 8px; margin: 20px;"><h2>Error Loading Application</h2><p>' + e.message + '</p><p>Please refresh the page or check the console for details.</p></div>';
            }
        });
        
        // =================================================================
        // ADVANCED ANIMATION SYSTEM
        // =================================================================

        // Particle System
        function createParticles() {
            const container = document.getElementById('particlesContainer');
            const particleCount = 30;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                
                // Random position
                particle.style.left = Math.random() * 100 + '%';
                particle.style.top = Math.random() * 100 + '%';
                
                // Random animation duration and delay
                const duration = 3 + Math.random() * 4;
                const delay = Math.random() * 3;
                particle.style.animationDuration = duration + 's';
                particle.style.animationDelay = delay + 's';
                
                // Random movement direction
                particle.style.setProperty('--tx', (Math.random() - 0.5) * 200 + 'px');
                particle.style.setProperty('--ty', (Math.random() - 0.5) * 200 + 'px');
                
                container.appendChild(particle);
            }
        }

        // Ripple Effect on Button Click
        function createRipple(event, element) {
            const ripple = document.createElement('span');
            ripple.className = 'ripple';
            
            const rect = element.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = event.clientX - rect.left - size / 2;
            const y = event.clientY - rect.top - size / 2;
            
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            
            element.appendChild(ripple);
            
            setTimeout(() => ripple.remove(), 600);
        }

        // Page Transition Animation
        function pageTransition(callback) {
            const overlay = document.getElementById('pageTransition');
            overlay.classList.add('active');
            
            setTimeout(() => {
                if (callback) callback();
                setTimeout(() => {
                    overlay.classList.remove('active');
                }, 300);
            }, 300);
        }

        // Confetti Celebration
        function createConfetti() {
            const colors = ['#0f4c75', '#3282b8', '#bbe1fa', '#10b981', '#f59e0b'];
            const confettiCount = 50;
            
            for (let i = 0; i < confettiCount; i++) {
                const confetti = document.createElement('div');
                confetti.className = 'confetti';
                confetti.style.left = Math.random() * 100 + '%';
                confetti.style.background = colors[Math.floor(Math.random() * colors.length)];
                confetti.style.animationDelay = Math.random() * 0.5 + 's';
                confetti.style.animationDuration = 2 + Math.random() * 2 + 's';
                
                document.body.appendChild(confetti);
                
                setTimeout(() => confetti.remove(), 4000);
            }
        }

        // Scroll Animation Observer
        function initScrollAnimations() {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('in-view');
                    }
                });
            }, {
                threshold: 0.1
            });

            document.querySelectorAll('.animate-on-scroll').forEach(el => {
                observer.observe(el);
            });
        }

        // Staggered Animation for Multiple Elements
        function staggerAnimation(elements, animationClass, delay = 100) {
            elements.forEach((el, index) => {
                setTimeout(() => {
                    el.classList.add(animationClass);
                }, index * delay);
            });
        }

        // Typing Effect for Text
        function typeText(element, text, speed = 50) {
            let i = 0;
            element.textContent = '';
            
            const interval = setInterval(() => {
                if (i < text.length) {
                    element.textContent += text.charAt(i);
                    i++;
                } else {
                    clearInterval(interval);
                }
            }, speed);
        }

        // Success Animation with Particle Burst
        function successBurst(element) {
            element.classList.add('success-animation');
            
            // Create particle burst
            const rect = element.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            
            for (let i = 0; i < 20; i++) {
                const particle = document.createElement('div');
                particle.style.position = 'fixed';
                particle.style.width = '6px';
                particle.style.height = '6px';
                particle.style.borderRadius = '50%';
                particle.style.background = '#10b981';
                particle.style.left = centerX + 'px';
                particle.style.top = centerY + 'px';
                particle.style.pointerEvents = 'none';
                particle.style.zIndex = '9999';
                
                const angle = (Math.PI * 2 * i) / 20;
                const velocity = 100 + Math.random() * 50;
                const tx = Math.cos(angle) * velocity;
                const ty = Math.sin(angle) * velocity;
                
                particle.style.setProperty('--tx', tx + 'px');
                particle.style.setProperty('--ty', ty + 'px');
                particle.style.animation = 'particleFloat 0.8s ease-out forwards';
                
                document.body.appendChild(particle);
                setTimeout(() => particle.remove(), 800);
            }
            
            setTimeout(() => {
                element.classList.remove('success-animation');
            }, 2000);
        }

        // Error Shake Animation
        function errorShake(element) {
            element.classList.add('error-animation');
            setTimeout(() => {
                element.classList.remove('error-animation');
            }, 500);
        }

        // Smooth Number Counter Animation
        function animateNumber(element, start, end, duration = 1000) {
            const range = end - start;
            const increment = range / (duration / 16);
            let current = start;
            
            const timer = setInterval(() => {
                current += increment;
                if ((increment > 0 && current >= end) || (increment < 0 && current <= end)) {
                    current = end;
                    clearInterval(timer);
                }
                element.textContent = Math.round(current);
            }, 16);
        }

        // =================================================================
        // STATE MANAGEMENT
        // =================================================================
        
        const appState = {
            currentPage: 'dashboard',
            scores: JSON.parse(localStorage.getItem('physicsScores')) || {
                electricity: 0,
                light: 0,
                humanEye: 0
            },
            streak: parseInt(localStorage.getItem('studyStreak')) || 0,
            lastVisit: localStorage.getItem('lastVisit') || null,
            quizStates: {
                electricity: { currentQuestion: 0, score: 0, answers: [] },
                light: { currentQuestion: 0, score: 0, answers: [] },
                humanEye: { currentQuestion: 0, score: 0, answers: [] }
            }
        };

        // Quiz Data
        const quizData = {
            electricity: [
                {
                    question: "What is the SI unit of electric current?",
                    options: ["Ampere (A)", "Volt (V)", "Ohm (Ω)", "Watt (W)"],
                    answer: 0,
                    explanation: "The SI unit of electric current is Ampere (A). It measures the rate of flow of electric charge. One ampere is defined as the flow of one coulomb of charge per second."
                },
                {
                    question: "Look at this circuit diagram. What type of circuit connection is shown?",
                    image: `<svg viewBox="0 0 400 200" style="max-width: 100%; height: auto; background: #fff; border-radius: 8px; padding: 20px;">
                        <!-- Battery -->
                        <line x1="50" y1="100" x2="80" y2="100" stroke="#000" stroke-width="2"/>
                        <line x1="80" y1="85" x2="80" y2="115" stroke="#000" stroke-width="3"/>
                        <line x1="90" y1="90" x2="90" y2="110" stroke="#000" stroke-width="2"/>
                        <text x="65" y="140" font-size="12" fill="#0f4c75">Battery</text>
                        
                        <!-- Wire to first resistor -->
                        <line x1="90" y1="100" x2="130" y2="100" stroke="#000" stroke-width="2"/>
                        
                        <!-- First Resistor (R1) -->
                        <rect x="130" y="90" width="40" height="20" fill="none" stroke="#000" stroke-width="2"/>
                        <line x="135" y="95" x2="165" y2="105" stroke="#000" stroke-width="1.5"/>
                        <line x="140" y="95" x2="160" y2="105" stroke="#000" stroke-width="1.5"/>
                        <text x="135" y="130" font-size="12" fill="#e74c3c">R₁</text>
                        
                        <!-- Wire to second resistor -->
                        <line x1="170" y1="100" x2="210" y2="100" stroke="#000" stroke-width="2"/>
                        
                        <!-- Second Resistor (R2) -->
                        <rect x="210" y="90" width="40" height="20" fill="none" stroke="#000" stroke-width="2"/>
                        <line x="215" y="95" x2="245" y2="105" stroke="#000" stroke-width="1.5"/>
                        <line x="220" y="95" x2="240" y2="105" stroke="#000" stroke-width="1.5"/>
                        <text x="215" y="130" font-size="12" fill="#e74c3c">R₂</text>
                        
                        <!-- Wire to third resistor -->
                        <line x1="250" y1="100" x2="290" y2="100" stroke="#000" stroke-width="2"/>
                        
                        <!-- Third Resistor (R3) -->
                        <rect x="290" y="90" width="40" height="20" fill="none" stroke="#000" stroke-width="2"/>
                        <line x="295" y="95" x2="325" y2="105" stroke="#000" stroke-width="1.5"/>
                        <line x="300" y="95" x2="320" y2="105" stroke="#000" stroke-width="1.5"/>
                        <text x="295" y="130" font-size="12" fill="#e74c3c">R₃</text>
                        
                        <!-- Return wire -->
                        <line x1="330" y1="100" x2="350" y2="100" stroke="#000" stroke-width="2"/>
                        <line x1="350" y1="100" x2="350" y2="150" stroke="#000" stroke-width="2"/>
                        <line x1="350" y1="150" x2="50" y2="150" stroke="#000" stroke-width="2"/>
                        <line x1="50" y1="150" x2="50" y2="100" stroke="#000" stroke-width="2"/>
                        
                        <!-- Current direction arrows -->
                        <path d="M 110 90 L 120 90 L 115 85 Z" fill="#3282b8"/>
                        <text x="105" y="80" font-size="11" fill="#3282b8" font-weight="bold">I</text>
                    </svg>`,
                    options: ["Series Circuit", "Parallel Circuit", "Mixed Circuit", "Open Circuit"],
                    answer: 0,
                    explanation: "This is a SERIES circuit. All resistors (R₁, R₂, R₃) are connected in a single path. In series circuits, the same current flows through all components, and total resistance is R_total = R₁ + R₂ + R₃."
                },
                {
                    question: "According to Ohm's Law, which formula is correct?",
                    options: ["V = I × R", "V = I / R", "V = R / I", "I = V × R"],
                    answer: 0,
                    explanation: "Ohm's Law states that V = I × R, where V is voltage (volts), I is current (amperes), and R is resistance (ohms). This fundamental relationship shows that voltage is directly proportional to current when resistance is constant."
                },
                {
                    question: "If the resistance in a circuit is doubled while voltage remains constant, what happens to the current?",
                    options: ["Current doubles", "Current halves", "Current remains same", "Current becomes zero"],
                    answer: 1,
                    explanation: "Using Ohm's Law (I = V/R), when resistance doubles and voltage remains constant, the current becomes half. This demonstrates the inverse relationship between current and resistance."
                },
                {
                    question: "Identify the circuit configuration shown in this diagram:",
                    image: `<svg viewBox="0 0 400 250" style="max-width: 100%; height: auto; background: #fff; border-radius: 8px; padding: 20px;">
                        <!-- Battery -->
                        <line x1="50" y1="80" x2="80" y2="80" stroke="#000" stroke-width="2"/>
                        <line x1="80" y1="65" x2="80" y2="95" stroke="#000" stroke-width="3"/>
                        <line x1="90" y1="70" x2="90" y2="90" stroke="#000" stroke-width="2"/>
                        <text x="60" y="115" font-size="12" fill="#0f4c75">12V</text>
                        
                        <!-- Main line up -->
                        <line x1="90" y1="80" x2="140" y2="80" stroke="#000" stroke-width="2"/>
                        <line x1="140" y1="80" x2="140" y2="50" stroke="#000" stroke-width="2"/>
                        
                        <!-- Branch 1 (R1) -->
                        <line x1="140" y1="50" x2="200" y2="50" stroke="#000" stroke-width="2"/>
                        <rect x="200" y="40" width="40" height="20" fill="none" stroke="#000" stroke-width="2"/>
                        <text x="205" y="35" font-size="12" fill="#e74c3c">R₁=4Ω</text>
                        <line x1="240" y1="50" x2="300" y2="50" stroke="#000" stroke-width="2"/>
                        
                        <!-- Branch point top -->
                        <circle cx="140" cy="80" r="3" fill="#000"/>
                        
                        <!-- Branch 2 (R2) -->
                        <line x1="140" y1="80" x2="200" y2="80" stroke="#000" stroke-width="2"/>
                        <rect x="200" y="70" width="40" height="20" fill="none" stroke="#000" stroke-width="2"/>
                        <text x="205" y="65" font-size="12" fill="#e74c3c">R₂=6Ω</text>
                        <line x1="240" y1="80" x2="300" y2="80" stroke="#000" stroke-width="2"/>
                        
                        <!-- Branch 3 (R3) -->
                        <line x1="140" y1="80" x2="140" y2="110" stroke="#000" stroke-width="2"/>
                        <line x1="140" y1="110" x2="200" y2="110" stroke="#000" stroke-width="2"/>
                        <rect x="200" y="100" width="40" height="20" fill="none" stroke="#000" stroke-width="2"/>
                        <text x="205" y="95" font-size="12" fill="#e74c3c">R₃=12Ω</text>
                        <line x1="240" y1="110" x2="300" y2="110" stroke="#000" stroke-width="2"/>
                        
                        <!-- Merge point -->
                        <circle cx="300" cy="80" r="3" fill="#000"/>
                        <line x1="300" y1="50" x2="300" y2="110" stroke="#000" stroke-width="2"/>
                        
                        <!-- Return to battery -->
                        <line x1="300" y1="80" x2="350" y2="80" stroke="#000" stroke-width="2"/>
                        <line x1="350" y1="80" x2="350" y2="180" stroke="#000" stroke-width="2"/>
                        <line x1="350" y1="180" x2="50" y2="180" stroke="#000" stroke-width="2"/>
                        <line x1="50" y1="180" x2="50" y2="80" stroke="#000" stroke-width="2"/>
                        
                        <!-- Arrows showing current split -->
                        <path d="M 115 75 L 125 75 L 120 70 Z" fill="#3282b8"/>
                        <text x="115" y="65" font-size="11" fill="#3282b8" font-weight="bold">I</text>
                    </svg>`,
                    options: ["Series Circuit", "Parallel Circuit", "Short Circuit", "Complex Series-Parallel"],
                    answer: 1,
                    explanation: "This is a PARALLEL circuit. All three resistors are connected across the same two points (same voltage). In parallel circuits: voltage is same across all branches, currents add up (I_total = I₁ + I₂ + I₃), and 1/R_total = 1/R₁ + 1/R₂ + 1/R₃."
                },
                {
                    question: "What is the unit of electrical resistance?",
                    options: ["Watt", "Volt", "Ohm", "Ampere"],
                    answer: 2,
                    explanation: "The SI unit of electrical resistance is Ohm (Ω), named after Georg Ohm. One ohm is defined as the resistance that allows one ampere of current to flow when one volt is applied."
                },
                {
                    question: "Electric power is measured in:",
                    options: ["Joules", "Watts", "Volts", "Amperes"],
                    answer: 1,
                    explanation: "Electric power is measured in Watts (W). One watt equals one joule of energy consumed per second. The formula for power is P = V × I."
                },
                {
                    question: "Which of the following materials is a good conductor of electricity?",
                    options: ["Rubber", "Copper", "Wood", "Plastic"],
                    answer: 1,
                    explanation: "Copper is an excellent conductor of electricity due to its free electrons that can move easily. Materials like rubber, wood, and plastic are insulators that resist electric current flow."
                },
                {
                    question: "In a series circuit with three equal resistors of 10Ω each, what is the total resistance?",
                    options: ["10Ω", "20Ω", "30Ω", "3.33Ω"],
                    answer: 2,
                    explanation: "In a series circuit, total resistance is the sum of all resistances: R_total = R₁ + R₂ + R₃ = 10 + 10 + 10 = 30Ω."
                },
                {
                    question: "The formula for electrical energy consumed is:",
                    options: ["E = P × t", "E = V × I", "E = I × R", "E = V / I"],
                    answer: 0,
                    explanation: "Electrical energy is calculated as E = P × t, where E is energy (joules), P is power (watts), and t is time (seconds). This can also be expressed as E = V × I × t."
                },
                {
                    question: "A 100W bulb is used for 10 hours. How much energy is consumed in kWh?",
                    options: ["0.1 kWh", "1 kWh", "10 kWh", "100 kWh"],
                    answer: 1,
                    explanation: "Energy = Power × Time = 100W × 10h = 1000 Wh = 1 kWh. Remember to convert watts to kilowatts (100W = 0.1kW) before multiplying by hours."
                },
                {
                    question: "What happens to the total resistance when resistors are connected in parallel?",
                    options: ["Increases", "Decreases", "Remains same", "Becomes infinite"],
                    answer: 1,
                    explanation: "In parallel circuits, total resistance decreases. The formula is 1/R_total = 1/R₁ + 1/R₂ + ... This is because parallel paths provide multiple routes for current flow."
                },
                {
                    question: "The heating effect of electric current is used in which device?",
                    options: ["Electric motor", "Electric bell", "Electric iron", "Electric generator"],
                    answer: 2,
                    explanation: "Electric iron uses the heating effect of current (Joule heating). When current flows through a high-resistance wire, electrical energy is converted to heat energy."
                },
                {
                    question: "If voltage across a conductor increases by 3 times and resistance remains constant, current will:",
                    options: ["Increase by 3 times", "Decrease by 3 times", "Remain same", "Increase by 9 times"],
                    answer: 0,
                    explanation: "From Ohm's Law (I = V/R), if voltage triples and resistance is constant, current also triples. This shows the direct proportionality between voltage and current."
                },
                {
                    question: "Which device is used to measure electric current?",
                    options: ["Voltmeter", "Ammeter", "Galvanometer", "Ohmmeter"],
                    answer: 1,
                    explanation: "An ammeter is used to measure electric current in a circuit. It is connected in series and has very low resistance to avoid affecting the circuit."
                },
                {
                    question: "The commercial unit of electrical energy is:",
                    options: ["Joule", "Watt", "Kilowatt-hour", "Volt-ampere"],
                    answer: 2,
                    explanation: "The kilowatt-hour (kWh) is the commercial unit of electrical energy used by electricity boards. 1 kWh = 1000 W × 3600 s = 3.6 × 10⁶ J."
                },
                {
                    question: "What is the power dissipated when 2A current flows through a 5Ω resistor?",
                    options: ["10W", "20W", "5W", "2.5W"],
                    answer: 1,
                    explanation: "Using P = I²R, Power = (2)² × 5 = 4 × 5 = 20W. Alternatively, we can calculate voltage first (V = IR = 10V) and then use P = VI = 10 × 2 = 20W."
                }
            ],
            light: [
                {
                    question: "The speed of light in vacuum is approximately:",
                    options: ["3 × 10⁸ m/s", "3 × 10⁶ m/s", "3 × 10⁵ m/s", "3 × 10⁷ m/s"],
                    answer: 0,
                    explanation: "The speed of light in vacuum is approximately 3 × 10⁸ m/s (300,000 km/s). This is a fundamental constant of nature denoted by 'c'."
                },
                {
                    question: "Which type of mirror is used in car headlights?",
                    options: ["Plane mirror", "Concave mirror", "Convex mirror", "Cylindrical mirror"],
                    answer: 1,
                    explanation: "Concave mirrors are used in car headlights because they can produce powerful parallel beams of light when the bulb is placed at the focus of the mirror."
                },
                {
                    question: "Look at this ray diagram. What type of mirror is shown and where is the object located?",
                    image: `<svg viewBox="0 0 500 300" style="max-width: 100%; height: auto; background: #fff; border-radius: 8px; padding: 20px;">
                        <!-- Mirror (Concave) -->
                        <path d="M 350 50 Q 380 150 350 250" fill="none" stroke="#2c3e50" stroke-width="4"/>
                        <path d="M 355 50 Q 385 150 355 250" fill="#95a5a6" opacity="0.3"/>
                        
                        <!-- Principal axis -->
                        <line x1="50" y1="150" x2="400" y2="150" stroke="#7f8c8d" stroke-width="1" stroke-dasharray="5,5"/>
                        <text x="405" y="155" font-size="11" fill="#7f8c8d">Principal Axis</text>
                        
                        <!-- Center of curvature (C) -->
                        <circle cx="250" cy="150" r="3" fill="#e74c3c"/>
                        <text x="245" y="170" font-size="12" fill="#e74c3c" font-weight="bold">C</text>
                        
                        <!-- Focus (F) -->
                        <circle cx="300" cy="150" r="3" fill="#3498db"/>
                        <text x="295" y="170" font-size="12" fill="#3498db" font-weight="bold">F</text>
                        
                        <!-- Pole (P) -->
                        <circle cx="350" cy="150" r="3" fill="#2c3e50"/>
                        <text x="355" y="145" font-size="12" fill="#2c3e50" font-weight="bold">P</text>
                        
                        <!-- Object -->
                        <line x1="200" y1="150" x2="200" y2="100" stroke="#27ae60" stroke-width="3"/>
                        <path d="M 200 100 L 195 110 L 205 110 Z" fill="#27ae60"/>
                        <text x="185" y="95" font-size="12" fill="#27ae60" font-weight="bold">Object</text>
                        
                        <!-- Ray 1: Parallel to axis, reflects through F -->
                        <line x1="200" y1="100" x2="350" y2="100" stroke="#e67e22" stroke-width="2"/>
                        <line x1="350" y1="100" x2="300" y2="150" stroke="#e67e22" stroke-width="2" stroke-dasharray="3,3"/>
                        
                        <!-- Ray 2: Through C, reflects back -->
                        <line x1="200" y1="100" x2="250" y2="150" stroke="#9b59b6" stroke-width="2"/>
                        <line x1="250" y1="150" x2="200" y2="200" stroke="#9b59b6" stroke-width="2" stroke-dasharray="3,3"/>
                        
                        <!-- Ray 3: Through F, reflects parallel -->
                        <line x1="200" y1="100" x2="300" y2="150" stroke="#16a085" stroke-width="2"/>
                        <line x1="300" y1="150" x2="350" y2="170" stroke="#16a085" stroke-width="2"/>
                        
                        <!-- Image (inverted) -->
                        <line x1="200" y1="150" x2="200" y2="200" stroke="#c0392b" stroke-width="3"/>
                        <path d="M 200 200 L 195 190 L 205 190 Z" fill="#c0392b"/>
                        <text x="185" y="215" font-size="12" fill="#c0392b" font-weight="bold">Image</text>
                        
                        <text x="150" y="30" font-size="14" fill="#0f4c75" font-weight="bold">Ray Diagram</text>
                    </svg>`,
                    options: ["Concave mirror, object beyond C", "Convex mirror, object at F", "Concave mirror, object between C and F", "Plane mirror, object at center"],
                    answer: 0,
                    explanation: "This is a CONCAVE mirror with the object placed beyond the center of curvature (C). When an object is beyond C: the image forms between C and F, is real, inverted, and diminished. This configuration is used in telescopes."
                },
                {
                    question: "The phenomenon of bending of light around corners is called:",
                    options: ["Reflection", "Refraction", "Diffraction", "Dispersion"],
                    answer: 2,
                    explanation: "Diffraction is the bending of light waves around obstacles and corners. This phenomenon becomes significant when the size of the obstacle is comparable to the wavelength of light."
                },
                {
                    question: "A convex lens has a focal length of 20 cm. What is its power?",
                    options: ["+5 D", "-5 D", "+0.05 D", "+20 D"],
                    answer: 0,
                    explanation: "Power (P) = 1/f (in meters) = 1/0.20 = +5 D (diopters). Convex lenses have positive power as they converge light rays."
                },
                {
                    question: "Analyze this lens ray diagram. What type of lens and image is formed?",
                    image: `<svg viewBox="0 0 500 300" style="max-width: 100%; height: auto; background: #fff; border-radius: 8px; padding: 20px;">
                        <!-- Convex Lens -->
                        <ellipse cx="250" cy="150" rx="8" ry="100" fill="none" stroke="#3498db" stroke-width="3"/>
                        <path d="M 242 60 Q 250 55 258 60" fill="none" stroke="#3498db" stroke-width="2"/>
                        <path d="M 242 240 Q 250 245 258 240" fill="none" stroke="#3498db" stroke-width="2"/>
                        
                        <!-- Principal axis -->
                        <line x1="50" y1="150" x2="450" y2="150" stroke="#7f8c8d" stroke-width="1" stroke-dasharray="5,5"/>
                        
                        <!-- Optical center (O) -->
                        <circle cx="250" cy="150" r="3" fill="#2c3e50"/>
                        <text x="245" y="140" font-size="11" fill="#2c3e50" font-weight="bold">O</text>
                        
                        <!-- Focus F1 (left) -->
                        <circle cx="180" cy="150" r="3" fill="#e74c3c"/>
                        <text x="175" y="140" font-size="11" fill="#e74c3c" font-weight="bold">F₁</text>
                        <line x1="180" y1="145" x2="180" y2="155" stroke="#e74c3c" stroke-width="1"/>
                        
                        <!-- Focus F2 (right) -->
                        <circle cx="320" cy="150" r="3" fill="#e74c3c"/>
                        <text x="315" y="140" font-size="11" fill="#e74c3c" font-weight="bold">F₂</text>
                        <line x1="320" y1="145" x2="320" y2="155" stroke="#e74c3c" stroke-width="1"/>
                        
                        <!-- Object -->
                        <line x1="130" y1="150" x2="130" y2="90" stroke="#27ae60" stroke-width="3"/>
                        <path d="M 130 90 L 125 100 L 135 100 Z" fill="#27ae60"/>
                        <text x="105" y="85" font-size="11" fill="#27ae60" font-weight="bold">Object</text>
                        
                        <!-- Ray 1: Parallel to axis, passes through F2 -->
                        <line x1="130" y1="90" x2="250" y2="90" stroke="#e67e22" stroke-width="2"/>
                        <line x1="250" y1="90" x2="320" y2="150" stroke="#e67e22" stroke-width="2"/>
                        <line x1="320" y1="150" x2="380" y2="195" stroke="#e67e22" stroke-width="2"/>
                        
                        <!-- Ray 2: Through optical center -->
                        <line x1="130" y1="90" x2="250" y2="150" stroke="#9b59b6" stroke-width="2"/>
                        <line x1="250" y1="150" x2="380" y2="215" stroke="#9b59b6" stroke-width="2"/>
                        
                        <!-- Ray 3: Through F1, emerges parallel -->
                        <line x1="130" y1="90" x2="180" y2="150" stroke="#16a085" stroke-width="2"/>
                        <line x1="180" y1="150" x2="250" y2="150" stroke="#16a085" stroke-width="2"/>
                        <line x1="250" y1="150" x2="380" y2="150" stroke="#16a085" stroke-width="2"/>
                        
                        <!-- Image (magnified, inverted) -->
                        <line x1="380" y1="150" x2="380" y2="215" stroke="#c0392b" stroke-width="3"/>
                        <path d="M 380 215 L 375 205 L 385 205 Z" fill="#c0392b"/>
                        <text x="385" y="220" font-size="11" fill="#c0392b" font-weight="bold">Image</text>
                        
                        <!-- Labels -->
                        <text x="200" y="30" font-size="13" fill="#0f4c75" font-weight="bold">Convex Lens Ray Diagram</text>
                    </svg>`,
                    options: ["Real, inverted, magnified", "Virtual, erect, magnified", "Real, erect, diminished", "Virtual, inverted, same size"],
                    answer: 0,
                    explanation: "The image is REAL, INVERTED, and MAGNIFIED. This occurs when the object is placed between F and 2F of a convex lens. All three rays converge on the other side to form a real image beyond 2F. This principle is used in projectors and cameras."
                },
                {
                    question: "The mirror formula is:",
                    options: ["1/f = 1/v + 1/u", "1/f = 1/v - 1/u", "f = v + u", "f = v - u"],
                    answer: 0,
                    explanation: "The mirror formula is 1/f = 1/v + 1/u, where f is focal length, v is image distance, and u is object distance. This formula is valid for all spherical mirrors."
                },
                {
                    question: "Which lens is used to correct hypermetropia (farsightedness)?",
                    options: ["Concave lens", "Convex lens", "Cylindrical lens", "Bifocal lens"],
                    answer: 1,
                    explanation: "Convex (converging) lenses are used to correct hypermetropia. They help converge light rays before they enter the eye, compensating for the shortened eyeball or reduced lens power."
                },
                {
                    question: "When light travels from air to glass, it:",
                    options: ["Speeds up", "Slows down", "Maintains speed", "Stops"],
                    answer: 1,
                    explanation: "Light slows down when it enters a denser medium like glass from air. This change in speed causes refraction (bending) of the light ray."
                },
                {
                    question: "The refractive index of a medium is defined as:",
                    options: ["Speed of light in vacuum / Speed in medium", "Speed in medium / Speed in vacuum", "Angle of incidence / Angle of refraction", "Wavelength in vacuum / Wavelength in medium"],
                    answer: 0,
                    explanation: "Refractive index (n) = Speed of light in vacuum (c) / Speed of light in medium (v). It is always greater than 1 for any material medium."
                },
                {
                    question: "A virtual image formed by a mirror is always:",
                    options: ["Inverted and real", "Erect and cannot be caught on screen", "Inverted and magnified", "Real and diminished"],
                    answer: 1,
                    explanation: "A virtual image is always erect and cannot be caught on a screen because the light rays do not actually converge; they only appear to diverge from a point behind the mirror."
                },
                {
                    question: "The phenomenon of splitting white light into its constituent colors is called:",
                    options: ["Reflection", "Refraction", "Dispersion", "Scattering"],
                    answer: 2,
                    explanation: "Dispersion is the phenomenon where white light splits into its constituent colors (VIBGYOR) when passing through a prism. This occurs because different colors have different wavelengths and refract at different angles."
                },
                {
                    question: "Which color of light has the shortest wavelength?",
                    options: ["Red", "Green", "Blue", "Violet"],
                    answer: 3,
                    explanation: "Violet light has the shortest wavelength (approximately 380-450 nm) in the visible spectrum. Red has the longest wavelength at approximately 620-750 nm."
                },
                {
                    question: "A concave mirror produces a magnified, erect image when object is placed:",
                    options: ["Beyond center of curvature", "At focus", "Between focus and pole", "At center of curvature"],
                    answer: 2,
                    explanation: "When an object is placed between the focus and pole of a concave mirror, it produces a virtual, magnified, and erect image behind the mirror. This principle is used in shaving mirrors."
                },
                {
                    question: "The lens formula is:",
                    options: ["1/f = 1/v - 1/u", "1/f = 1/v + 1/u", "f = v - u", "f = v + u"],
                    answer: 0,
                    explanation: "The lens formula is 1/f = 1/v - 1/u, where f is focal length, v is image distance, and u is object distance (taken as negative for real objects)."
                },
                {
                    question: "Twinkling of stars is due to:",
                    options: ["Reflection", "Refraction", "Diffraction", "Total internal reflection"],
                    answer: 1,
                    explanation: "Twinkling of stars (scintillation) is due to atmospheric refraction. The varying density of air layers causes the path of starlight to continuously change, making stars appear to twinkle."
                },
                {
                    question: "A ray of light parallel to the principal axis, after reflection from a convex mirror:",
                    options: ["Passes through focus", "Appears to come from focus", "Remains parallel", "Passes through center of curvature"],
                    answer: 1,
                    explanation: "For a convex mirror, a ray parallel to the principal axis appears to diverge from the focus after reflection. The reflected rays appear to come from the virtual focus behind the mirror."
                }
            ],
            humanEye: [
                {
                    question: "Study this cross-section of the human eye. Identify the part labeled 'X' that controls light entry:",
                    image: `<svg viewBox="0 0 500 350" style="max-width: 100%; height: auto; background: #fff; border-radius: 8px; padding: 20px;">
                        <!-- Eye outline -->
                        <ellipse cx="250" cy="175" rx="180" ry="140" fill="#f8f9fa" stroke="#2c3e50" stroke-width="3"/>
                        
                        <!-- Sclera (white part) -->
                        <ellipse cx="250" cy="175" rx="175" ry="135" fill="#ffffff" stroke="#2c3e50" stroke-width="2"/>
                        
                        <!-- Iris (colored part) - marked as X -->
                        <circle cx="160" cy="175" r="50" fill="#4a90e2" stroke="#2c3e50" stroke-width="2"/>
                        <circle cx="160" cy="175" r="48" fill="none" stroke="#fff" stroke-width="1" opacity="0.3"/>
                        
                        <!-- Pupil (black center) -->
                        <circle cx="160" cy="175" r="25" fill="#000000"/>
                        
                        <!-- Cornea (transparent front) -->
                        <ellipse cx="145" cy="175" rx="60" ry="75" fill="none" stroke="#3498db" stroke-width="2" opacity="0.6"/>
                        <path d="M 105 175 Q 90 175 90 175" stroke="#3498db" stroke-width="2" opacity="0.4"/>
                        
                        <!-- Lens -->
                        <ellipse cx="200" cy="175" rx="20" ry="35" fill="#e8f4f8" stroke="#2c3e50" stroke-width="2"/>
                        
                        <!-- Retina (back layer) -->
                        <path d="M 350 100 Q 400 175 350 250" fill="none" stroke="#e74c3c" stroke-width="3"/>
                        <circle cx="350" cy="175" r="4" fill="#e74c3c"/>
                        
                        <!-- Optic nerve -->
                        <ellipse cx="370" cy="175" rx="15" ry="20" fill="#f39c12" stroke="#2c3e50" stroke-width="2"/>
                        <line x1="385" y1="175" x2="420" y2="175" stroke="#f39c12" stroke-width="8"/>
                        
                        <!-- Light rays entering -->
                        <line x1="20" y1="150" x2="105" y2="165" stroke="#ffd700" stroke-width="2" marker-end="url(#arrowhead)"/>
                        <line x1="20" y1="175" x2="105" y2="175" stroke="#ffd700" stroke-width="2" marker-end="url(#arrowhead)"/>
                        <line x1="20" y1="200" x2="105" y2="185" stroke="#ffd700" stroke-width="2" marker-end="url(#arrowhead)"/>
                        
                        <!-- Labels -->
                        <text x="160" y="120" font-size="20" fill="#c0392b" font-weight="bold" text-anchor="middle">X</text>
                        <circle cx="160" cy="125" r="15" fill="none" stroke="#c0392b" stroke-width="2"/>
                        
                        <text x="145" y="270" font-size="11" fill="#3498db">Cornea</text>
                        <text x="155" y="145" font-size="11" fill="#000">Pupil</text>
                        <text x="200" y="220" font-size="11" fill="#2c3e50">Lens</text>
                        <text x="345" y="160" font-size="11" fill="#e74c3c">Retina</text>
                        <text x="370" y="200" font-size="11" fill="#f39c12">Optic Nerve</text>
                        
                        <text x="250" y="30" font-size="14" fill="#0f4c75" font-weight="bold" text-anchor="middle">Human Eye - Cross Section</text>
                        
                        <!-- Arrow marker definition -->
                        <defs>
                            <marker id="arrowhead" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
                                <polygon points="0 0, 10 3, 0 6" fill="#ffd700"/>
                            </marker>
                        </defs>
                    </svg>`,
                    options: ["Cornea", "Iris", "Lens", "Retina"],
                    answer: 1,
                    explanation: "Part 'X' is the IRIS - the colored part of the eye that controls the amount of light entering through the pupil. It contains muscles that contract in bright light (making pupil smaller) and relax in dim light (making pupil larger). The iris gives eyes their color (brown, blue, green, etc.)."
                },
                {
                    question: "Which part of the eye controls the amount of light entering?",
                    options: ["Cornea", "Iris", "Lens", "Retina"],
                    answer: 1,
                    explanation: "The iris controls the amount of light entering the eye by adjusting the size of the pupil. In bright light, the iris contracts the pupil; in dim light, it expands the pupil."
                },
                {
                    question: "The image formed on the retina is:",
                    options: ["Real and inverted", "Virtual and erect", "Real and erect", "Virtual and inverted"],
                    answer: 0,
                    explanation: "The eye lens forms a real and inverted image on the retina. However, the brain interprets this image as erect, allowing us to perceive objects in their correct orientation."
                },
                {
                    question: "Myopia (nearsightedness) can be corrected using:",
                    options: ["Convex lens", "Concave lens", "Cylindrical lens", "Bifocal lens"],
                    answer: 1,
                    explanation: "Myopia is corrected using concave (diverging) lenses. In myopia, the image forms before the retina; a concave lens diverges light rays, helping the image form correctly on the retina."
                },
                {
                    question: "This diagram shows vision correction. What defect is being corrected and how?",
                    image: `<svg viewBox="0 0 550 280" style="max-width: 100%; height: auto; background: #fff; border-radius: 8px; padding: 20px;">
                        <!-- Title -->
                        <text x="275" y="25" font-size="13" fill="#0f4c75" font-weight="bold" text-anchor="middle">Vision Defect Correction</text>
                        
                        <!-- BEFORE CORRECTION -->
                        <text x="140" y="50" font-size="12" fill="#e74c3c" font-weight="bold" text-anchor="middle">BEFORE: Defective Eye</text>
                        
                        <!-- Eye outline (elongated) -->
                        <ellipse cx="140" cy="120" rx="90" ry="50" fill="#f8f9fa" stroke="#2c3e50" stroke-width="2"/>
                        
                        <!-- Lens in eye -->
                        <ellipse cx="70" cy="120" rx="10" ry="20" fill="#e8f4f8" stroke="#2c3e50" stroke-width="1.5"/>
                        
                        <!-- Retina -->
                        <path d="M 210 85 Q 225 120 210 155" stroke="#e74c3c" stroke-width="2.5"/>
                        <text x="235" y="125" font-size="10" fill="#e74c3c">Retina</text>
                        
                        <!-- Light rays converging BEFORE retina -->
                        <line x1="10" y1="100" x2="70" y2="110" stroke="#3498db" stroke-width="2"/>
                        <line x1="10" y1="120" x2="70" y2="120" stroke="#3498db" stroke-width="2"/>
                        <line x1="10" y1="140" x2="70" y2="130" stroke="#3498db" stroke-width="2"/>
                        
                        <!-- Converging to point before retina -->
                        <line x1="70" y1="110" x2="170" y2="120" stroke="#3498db" stroke-width="2"/>
                        <line x1="70" y1="120" x2="170" y2="120" stroke="#3498db" stroke-width="2"/>
                        <line x1="70" y1="130" x2="170" y2="120" stroke="#3498db" stroke-width="2"/>
                        
                        <!-- Focus point (wrong position) -->
                        <circle cx="170" cy="120" r="4" fill="#e74c3c"/>
                        <text x="175" y="115" font-size="10" fill="#e74c3c">Image</text>
                        
                        <!-- Diverging after focus -->
                        <line x1="170" y1="120" x2="210" y2="110" stroke="#3498db" stroke-width="2" stroke-dasharray="2,2"/>
                        <line x1="170" y1="120" x2="210" y2="130" stroke="#3498db" stroke-width="2" stroke-dasharray="2,2"/>
                        
                        <!-- AFTER CORRECTION -->
                        <text x="410" y="50" font-size="12" fill="#27ae60" font-weight="bold" text-anchor="middle">AFTER: With Corrective Lens</text>
                        
                        <!-- Concave lens (diverging) -->
                        <path d="M 310 95 Q 305 120 310 145" fill="#e8f4f8" stroke="#9b59b6" stroke-width="3"/>
                        <path d="M 320 95 Q 315 120 320 145" fill="#e8f4f8" stroke="#9b59b6" stroke-width="3"/>
                        <text x="300" y="170" font-size="11" fill="#9b59b6" font-weight="bold">Concave Lens</text>
                        
                        <!-- Eye outline (same) -->
                        <ellipse cx="410" cy="120" rx="90" ry="50" fill="#f8f9fa" stroke="#2c3e50" stroke-width="2"/>
                        
                        <!-- Lens in eye -->
                        <ellipse cx="340" cy="120" rx="10" ry="20" fill="#e8f4f8" stroke="#2c3e50" stroke-width="1.5"/>
                        
                        <!-- Retina -->
                        <path d="M 480 85 Q 495 120 480 155" stroke="#27ae60" stroke-width="2.5"/>
                        <text x="505" y="125" font-size="10" fill="#27ae60">Retina</text>
                        
                        <!-- Light rays entering concave lens -->
                        <line x1="280" y1="100" x2="310" y2="105" stroke="#3498db" stroke-width="2"/>
                        <line x1="280" y1="120" x2="310" y2="120" stroke="#3498db" stroke-width="2"/>
                        <line x1="280" y1="140" x2="310" y2="135" stroke="#3498db" stroke-width="2"/>
                        
                        <!-- Diverging from concave lens -->
                        <line x1="315" y1="105" x2="340" y2="100" stroke="#3498db" stroke-width="2"/>
                        <line x1="315" y1="120" x2="340" y2="120" stroke="#3498db" stroke-width="2"/>
                        <line x1="315" y1="135" x2="340" y2="140" stroke="#3498db" stroke-width="2"/>
                        
                        <!-- Converging properly on retina -->
                        <line x1="340" y1="100" x2="480" y2="120" stroke="#3498db" stroke-width="2"/>
                        <line x1="340" y1="120" x2="480" y2="120" stroke="#3498db" stroke-width="2"/>
                        <line x1="340" y1="140" x2="480" y2="120" stroke="#3498db" stroke-width="2"/>
                        
                        <!-- Focus point (correct position on retina) -->
                        <circle cx="480" cy="120" r="4" fill="#27ae60"/>
                        <text x="485" y="115" font-size="10" fill="#27ae60">Sharp Image</text>
                        
                        <!-- Arrow between diagrams -->
                        <path d="M 250 120 L 270 120" stroke="#7f8c8d" stroke-width="2" marker-end="url(#arrow2)"/>
                        <text x="260" y="115" font-size="11" fill="#7f8c8d" text-anchor="middle">Fix</text>
                        
                        <defs>
                            <marker id="arrow2" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto">
                                <polygon points="0 0, 10 3, 0 6" fill="#7f8c8d"/>
                            </marker>
                        </defs>
                    </svg>`,
                    options: ["Hypermetropia with convex lens", "Myopia with concave lens", "Presbyopia with bifocal lens", "Astigmatism with cylindrical lens"],
                    answer: 1,
                    explanation: "This shows MYOPIA (nearsightedness) correction using a CONCAVE LENS. In myopia, the eyeball is too long, causing the image to focus before the retina. The concave (diverging) lens spreads out the light rays before they enter the eye, so they converge properly on the retina, producing a sharp image."
                },
                {
                    question: "The least distance of distinct vision for a normal human eye is:",
                    options: ["10 cm", "25 cm", "50 cm", "100 cm"],
                    answer: 1,
                    explanation: "The least distance of distinct vision (near point) for a normal human eye is approximately 25 cm. Objects closer than this appear blurred as the eye cannot focus properly."
                },
                {
                    question: "Which part of the eye contains light-sensitive cells?",
                    options: ["Cornea", "Iris", "Lens", "Retina"],
                    answer: 3,
                    explanation: "The retina contains light-sensitive cells called rods and cones. Rods are responsible for vision in dim light, while cones detect color and work best in bright light."
                },
                {
                    question: "The ability of the eye lens to adjust its focal length is called:",
                    options: ["Adaptation", "Accommodation", "Refraction", "Reflection"],
                    answer: 1,
                    explanation: "Accommodation is the ability of the eye lens to change its focal length by becoming thicker or thinner with the help of ciliary muscles, allowing us to focus on objects at varying distances."
                },
                {
                    question: "Hypermetropia (farsightedness) occurs when:",
                    options: ["Eyeball is too long", "Eyeball is too short", "Cornea is damaged", "Iris is defective"],
                    answer: 1,
                    explanation: "Hypermetropia occurs when the eyeball is too short or the lens has insufficient converging power. This causes the image to form behind the retina, making nearby objects appear blurred."
                },
                {
                    question: "The defect of the eye where the cornea or lens is not perfectly spherical is called:",
                    options: ["Myopia", "Hypermetropia", "Astigmatism", "Presbyopia"],
                    answer: 2,
                    explanation: "Astigmatism is a defect where the cornea or lens is not perfectly spherical, causing different curvatures in different directions. It is corrected using cylindrical lenses."
                },
                {
                    question: "The far point of a myopic eye is:",
                    options: ["At infinity", "At 25 cm", "At less than infinity", "Beyond infinity"],
                    answer: 2,
                    explanation: "In myopia, the far point (the farthest point that can be seen clearly) is at a finite distance less than infinity. A normal eye has its far point at infinity."
                },
                {
                    question: "Which cells in the retina are responsible for color vision?",
                    options: ["Rods", "Cones", "Both rods and cones", "Cornea"],
                    answer: 1,
                    explanation: "Cone cells in the retina are responsible for color vision and work best in bright light. There are three types of cones sensitive to red, green, and blue light."
                },
                {
                    question: "Presbyopia is corrected using:",
                    options: ["Concave lens", "Convex lens", "Bifocal lens", "Cylindrical lens"],
                    answer: 2,
                    explanation: "Presbyopia, which occurs with aging due to loss of accommodation, is corrected using bifocal lenses. The upper part (concave) helps see distant objects, while the lower part (convex) helps read."
                },
                {
                    question: "The colored part of the eye is:",
                    options: ["Cornea", "Iris", "Pupil", "Retina"],
                    answer: 1,
                    explanation: "The iris is the colored part of the eye. It contains muscles that control the size of the pupil and gives the eye its characteristic color (brown, blue, green, etc.)."
                }
            ]
        };

        // Page Templates
        const pages = {
            dashboard: () => `
                <div class="content-header slide-in-left">
                    <h2>Dashboard</h2>
                    <div class="breadcrumb">Home / Dashboard</div>
                </div>

                <div class="stats-grid">
                    <div class="stat-card scale-in stagger-1 hover-lift ripple-effect" onclick="event.currentTarget.classList.contains('ripple-effect') && createRipple(event, event.currentTarget)">
                        <h4>Total Score</h4>
                        <div class="stat-value" data-count="${calculateTotalScore()}">${calculateTotalScore()}%</div>
                    </div>
                    <div class="stat-card scale-in stagger-2 hover-lift ripple-effect" onclick="event.currentTarget.classList.contains('ripple-effect') && createRipple(event, event.currentTarget)">
                        <h4>Completed</h4>
                        <div class="stat-value">${calculateCompletedQuizzes()}/3</div>
                    </div>
                    <div class="stat-card scale-in stagger-3 hover-lift ripple-effect" onclick="event.currentTarget.classList.contains('ripple-effect') && createRipple(event, event.currentTarget)">
                        <h4>Study Streak</h4>
                        <div class="stat-value float-animation">${appState.streak} 🔥</div>
                    </div>
                    <div class="stat-card scale-in stagger-4 hover-lift ripple-effect" onclick="event.currentTarget.classList.contains('ripple-effect') && createRipple(event, event.currentTarget)">
                        <h4>Questions Solved</h4>
                        <div class="stat-value" data-count="${calculateTotalQuestions()}">${calculateTotalQuestions()}</div>
                    </div>
                </div>

                <div class="formula-card bounce-in stagger-5 animated-gradient">
                    <h3 class="float-animation">⚡ Formula of the Day</h3>
                    <div class="formula-display">
                        \\[\\frac{1}{f} = \\frac{1}{v} + \\frac{1}{u}\\]
                    </div>
                    <div class="formula-explanation">
                        This is the <strong>Mirror Formula</strong>, relating focal length (f), object distance (u), and image distance (v) for spherical mirrors. Essential for solving problems in optics!
                    </div>
                </div>

                <div class="dashboard-grid">
                    <div class="chapter-card bounce-in stagger-1 hover-lift ripple-effect" onclick="createRipple(event, event.currentTarget); navigateTo('electricity')">
                        <div class="chapter-icon float-animation">⚡</div>
                        <h3>Electricity</h3>
                        <p>Master Ohm's Law, circuits, and electrical energy concepts</p>
                        <div class="progress-container">
                            <div class="progress-label">
                                <span>Progress</span>
                                <span>${appState.scores.electricity}%</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: ${appState.scores.electricity}%"></div>
                            </div>
                        </div>
                    </div>

                    <div class="chapter-card bounce-in stagger-2 hover-lift ripple-effect" onclick="createRipple(event, event.currentTarget); navigateTo('light')">
                        <div class="chapter-icon float-animation">💡</div>
                        <h3>Light - Reflection & Refraction</h3>
                        <p>Explore mirrors, lenses, and the fascinating behavior of light</p>
                        <div class="progress-container">
                            <div class="progress-label">
                                <span>Progress</span>
                                <span>${appState.scores.light}%</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: ${appState.scores.light}%"></div>
                            </div>
                        </div>
                    </div>

                    <div class="chapter-card bounce-in stagger-3 hover-lift ripple-effect" onclick="createRipple(event, event.currentTarget); navigateTo('human-eye')">
                        <div class="chapter-icon float-animation">👁️</div>
                        <h3>The Human Eye</h3>
                        <p>Understand eye structure, vision defects, and optical instruments</p>
                        <div class="progress-container">
                            <div class="progress-label">
                                <span>Progress</span>
                                <span>${appState.scores.humanEye}%</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: ${appState.scores.humanEye}%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            `,
            
            electricity: () => renderQuizPage('electricity', 'Electricity', '⚡'),
            light: () => renderQuizPage('light', 'Light - Reflection & Refraction', '💡'),
            'human-eye': () => renderQuizPage('humanEye', 'The Human Eye', '👁️')
        };

        // Helper Functions
        function calculateTotalScore() {
            const total = appState.scores.electricity + appState.scores.light + appState.scores.humanEye;
            return Math.round(total / 3);
        }

        function calculateCompletedQuizzes() {
            let completed = 0;
            if (appState.scores.electricity > 0) completed++;
            if (appState.scores.light > 0) completed++;
            if (appState.scores.humanEye > 0) completed++;
            return completed;
        }

        function calculateTotalQuestions() {
            const electricity = Math.round((appState.scores.electricity / 100) * quizData.electricity.length);
            const light = Math.round((appState.scores.light / 100) * quizData.light.length);
            const humanEye = Math.round((appState.scores.humanEye / 100) * quizData.humanEye.length);
            return electricity + light + humanEye;
        }

        function renderQuizPage(quizKey, title, icon) {
            const quiz = quizData[quizKey];
            const state = appState.quizStates[quizKey];
            
            if (state.currentQuestion >= quiz.length) {
                return renderResultPage(quizKey, title, icon);
            }

            const question = quiz[state.currentQuestion];
            
            return `
                <div class="content-header fade-in">
                    <h2>${icon} ${title}</h2>
                    <div class="breadcrumb">Home / ${title}</div>
                </div>

                <div class="quiz-container fade-in">
                    <div class="quiz-header">
                        <div class="quiz-progress">
                            Question ${state.currentQuestion + 1} of ${quiz.length}
                        </div>
                        <div class="quiz-score">
                            Score: ${state.score}/${state.currentQuestion}
                        </div>
                    </div>

                    <div class="question-card">
                        <div class="question-text">${question.question}</div>
                        
                        ${question.image ? `
                            <div class="question-image scale-in" style="margin: 1.5rem 0; padding: 1rem; background: linear-gradient(135deg, rgba(15, 76, 117, 0.03), rgba(50, 130, 184, 0.03)); border-radius: 12px; border: 2px solid var(--accent-tertiary);">
                                ${question.image}
                            </div>
                        ` : ''}
                        
                        <div class="options-grid" id="optionsGrid">
                            ${question.options.map((option, index) => `
                                <button class="option-button ripple-effect" onclick="createRipple(event, event.currentTarget); selectAnswer(${index}, '${quizKey}')">
                                    ${option}
                                </button>
                            `).join('')}
                        </div>
                    </div>

                    <div class="explanation-box" id="explanationBox">
                        <h4 id="explanationTitle"></h4>
                        <p id="explanationText"></p>
                    </div>

                    <button class="next-button ripple-effect" id="nextButton" onclick="createRipple(event, event.currentTarget); nextQuestion('${quizKey}')">
                        ${state.currentQuestion < quiz.length - 1 ? 'Next Question' : 'View Results'}
                    </button>
                </div>
            `;
        }

        function renderResultPage(quizKey, title, icon) {
            const quiz = quizData[quizKey];
            const state = appState.quizStates[quizKey];
            const percentage = Math.round((state.score / quiz.length) * 100);
            
            // Save score
            const scoreMap = {
                'electricity': 'electricity',
                'light': 'light',
                'humanEye': 'humanEye'
            };
            appState.scores[scoreMap[quizKey]] = percentage;
            saveToLocalStorage();

            let emoji = '🎉';
            let message = 'Great job!';
            let shouldCelebrate = false;
            
            if (percentage >= 90) {
                emoji = '🏆';
                message = 'Outstanding! You\'ve mastered this chapter!';
                shouldCelebrate = true;
            } else if (percentage >= 70) {
                emoji = '🎯';
                message = 'Well done! You have a strong understanding!';
                shouldCelebrate = true;
            } else if (percentage >= 50) {
                emoji = '📚';
                message = 'Good effort! Review the concepts and try again!';
            } else {
                emoji = '💪';
                message = 'Keep practicing! Understanding takes time!';
            }

            // Trigger confetti for good scores
            if (shouldCelebrate) {
                setTimeout(() => createConfetti(), 500);
            }

            return `
                <div class="content-header slide-in-left">
                    <h2>${icon} ${title} - Results</h2>
                    <div class="breadcrumb">Home / ${title} / Results</div>
                </div>

                <div class="quiz-container scale-in">
                    <div class="result-card">
                        <div class="result-emoji bounce-in">${emoji}</div>
                        <div class="result-title fade-in stagger-1">Quiz Complete!</div>
                        <div class="result-score rotate-in stagger-2">${state.score}/${quiz.length}</div>
                        <div class="result-percentage scale-in stagger-3">${percentage}% Correct</div>
                        <div class="result-message fade-in stagger-4">${message}</div>
                        
                        <div class="action-buttons">
                            <button class="action-button ripple-effect hover-lift" onclick="createRipple(event, event.currentTarget); retryQuiz('${quizKey}')">
                                Try Again
                            </button>
                            <button class="action-button secondary ripple-effect hover-lift" onclick="createRipple(event, event.currentTarget); navigateTo('dashboard')">
                                Back to Dashboard
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }

        // Quiz Functions
        function selectAnswer(selectedIndex, quizKey) {
            const quiz = quizData[quizKey];
            const state = appState.quizStates[quizKey];
            const question = quiz[state.currentQuestion];
            
            const buttons = document.querySelectorAll('.option-button');
            buttons.forEach((btn, index) => {
                btn.disabled = true;
                if (index === question.answer) {
                    btn.classList.add('correct');
                    // Success animation with particle burst
                    if (index === selectedIndex) {
                        setTimeout(() => successBurst(btn), 100);
                    }
                } else if (index === selectedIndex) {
                    btn.classList.add('incorrect');
                    // Error shake animation
                    errorShake(btn);
                }
            });

            const explanationBox = document.getElementById('explanationBox');
            const explanationTitle = document.getElementById('explanationTitle');
            const explanationText = document.getElementById('explanationText');
            
            if (selectedIndex === question.answer) {
                state.score++;
                explanationTitle.textContent = '✅ Correct!';
                explanationTitle.style.color = 'var(--success)';
            } else {
                explanationTitle.textContent = '❌ Incorrect';
                explanationTitle.style.color = 'var(--error)';
            }
            
            explanationText.textContent = question.explanation;
            explanationBox.classList.add('show');
            
            const nextButton = document.getElementById('nextButton');
            nextButton.classList.add('show');

            // Render math in explanation with error handling
            setTimeout(() => {
                try {
                    if (typeof renderMathInElement === 'function') {
                        renderMathInElement(explanationBox, {
                            delimiters: [
                                {left: '\\[', right: '\\]', display: true},
                                {left: '\\(', right: '\\)', display: false}
                            ],
                            throwOnError: false
                        });
                    }
                } catch (error) {
                    console.log('Math rendering in explanation skipped:', error);
                }
            }, 50);
        }

        function nextQuestion(quizKey) {
            appState.quizStates[quizKey].currentQuestion++;
            navigateTo(quizKey === 'humanEye' ? 'human-eye' : quizKey);
        }

        function retryQuiz(quizKey) {
            appState.quizStates[quizKey] = {
                currentQuestion: 0,
                score: 0,
                answers: []
            };
            navigateTo(quizKey === 'humanEye' ? 'human-eye' : quizKey);
        }

        // Navigation Functions
        function navigateTo(pageKey, clickedElement) {
            // Use page transition animation
            pageTransition(() => {
                appState.currentPage = pageKey;
                
                // Update active nav item
                document.querySelectorAll('.nav-item').forEach(item => {
                    item.classList.remove('active');
                });
                
                // Find and activate the correct nav item
                const navItems = document.querySelectorAll('.nav-item');
                navItems.forEach(item => {
                    const itemText = item.textContent.trim().toLowerCase();
                    if ((pageKey === 'dashboard' && itemText.includes('dashboard')) ||
                        (pageKey === 'electricity' && itemText.includes('electricity')) ||
                        (pageKey === 'light' && itemText.includes('light')) ||
                        (pageKey === 'human-eye' && itemText.includes('human eye'))) {
                        item.classList.add('active');
                    }
                });
                
                // Map page keys to quiz keys
                const pageToQuizKey = {
                    'electricity': 'electricity',
                    'light': 'light',
                    'human-eye': 'humanEye'
                };
                
                // Render page content
                const mainContent = document.getElementById('mainContent');
                if (pages[pageKey]) {
                    mainContent.innerHTML = pages[pageKey]();
                    
                    // Animate numbers on dashboard
                    if (pageKey === 'dashboard') {
                        setTimeout(() => {
                            document.querySelectorAll('.stat-value[data-count]').forEach(el => {
                                const count = parseInt(el.getAttribute('data-count'));
                                animateNumber(el, 0, count, 1000);
                            });
                        }, 200);
                    }
                    
                    // Render math formulas with error handling
                    setTimeout(() => {
                        try {
                            if (typeof renderMathInElement === 'function') {
                                renderMathInElement(mainContent, {
                                    delimiters: [
                                        {left: '\\[', right: '\\]', display: true},
                                        {left: '\\(', right: '\\)', display: false}
                                    ],
                                    throwOnError: false
                                });
                            }
                        } catch (error) {
                            console.log('Math rendering skipped:', error);
                        }
                    }, 100);
                }
                
                // Update streak
                updateStreak();
                
                // Close mobile menu
                if (window.innerWidth <= 768) {
                    document.getElementById('sidebar').classList.remove('active');
                }
            });
        }

        // Local Storage Functions
        function saveToLocalStorage() {
            localStorage.setItem('physicsScores', JSON.stringify(appState.scores));
            localStorage.setItem('studyStreak', appState.streak.toString());
            localStorage.setItem('lastVisit', new Date().toDateString());
        }

        function updateStreak() {
            const today = new Date().toDateString();
            if (appState.lastVisit !== today) {
                appState.streak++;
                appState.lastVisit = today;
                saveToLocalStorage();
            }
        }

        // Mobile Menu Toggle
        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('active');
        }

        // Initialize App
        window.addEventListener('load', () => {
            try {
                console.log('Physics Wayground: Initializing...');
                
                // Create particle background
                createParticles();
                console.log('Particles created');
                
                // Initial render
                navigateTo('dashboard');
                console.log('Dashboard loaded');
                
                // Initialize scroll animations
                initScrollAnimations();
                
                // Add ripple effect to nav items
                document.querySelectorAll('.nav-item').forEach(item => {
                    item.classList.add('ripple-effect');
                    item.addEventListener('click', (e) => {
                        createRipple(e, item);
                    });
                });
                
                // Close sidebar when clicking outside on mobile
                document.addEventListener('click', (e) => {
                    const sidebar = document.getElementById('sidebar');
                    const menuToggle = document.querySelector('.menu-toggle');
                    
                    if (window.innerWidth <= 768 && 
                        sidebar.classList.contains('active') && 
                        !sidebar.contains(e.target) && 
                        !menuToggle.contains(e.target)) {
                        sidebar.classList.remove('active');
                    }
                });
                
                console.log('Physics Wayground: Initialization complete!');
            } catch (error) {
                console.error('Initialization error:', error);
                // Fallback to basic initialization
                const mainContent = document.getElementById('mainContent');
                if (mainContent && !mainContent.innerHTML) {
                    // Try simple navigation without animations
                    appState.currentPage = 'dashboard';
                    if (pages.dashboard) {
                        mainContent.innerHTML = pages.dashboard();
                    }
                }
            }
        });

        // Fallback if window.load doesn't fire
        if (document.readyState === 'complete' || document.readyState === 'interactive') {
            setTimeout(() => {
                const mainContent = document.getElementById('mainContent');
                if (!mainContent || !mainContent.innerHTML) {
                    console.log('Using fallback initialization');
                    try {
                        createParticles();
                        navigateTo('dashboard');
                    } catch (error) {
                        console.error('Fallback error:', error);
                        // Last resort: direct render
                        if (mainContent) {
                            appState.currentPage = 'dashboard';
                            mainContent.innerHTML = pages.dashboard ? pages.dashboard() : '<p>Loading...</p>';
                        }
                    }
                }
            }, 100);
        } else {
            document.addEventListener('DOMContentLoaded', () => {
                try {
                    createParticles();
                    navigateTo('dashboard');
                } catch (error) {
                    console.error('DOMContentLoaded error:', error);
                }
            });
        }
