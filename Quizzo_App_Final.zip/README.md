# ⚡ Physics Wayground

> An interactive quiz app for **Class 10 Physics** — built with pure HTML, CSS & JavaScript.

![HTML](https://img.shields.io/badge/HTML5-E34F26?style=flat&logo=html5&logoColor=white)
![CSS](https://img.shields.io/badge/CSS3-1572B6?style=flat&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=flat&logo=javascript&logoColor=black)
![KaTeX](https://img.shields.io/badge/KaTeX-0.16.9-blue?style=flat)

---

## 📌 Overview

**Physics Wayground** is a browser-based quiz application designed to help Class 10 students practice and revise Physics. It runs entirely in the browser — no server, no install, no dependencies.

---

## 📁 Project Structure

```
Quizzo_App/
├── index.html      → App layout & HTML structure
├── styles.css      → UI design, animations, responsive styles
├── script.js       → Quiz engine, data, navigation & state
└── README.md       → Project documentation
```

---

## 🚀 Quick Start

```bash
# 1. Download and extract the ZIP
# 2. Open in browser — that's it!
open index.html
```

> ⚠️ All three files must stay in the **same folder**.

---

## 📚 Chapters

- ⚡ **Electricity** — Ohm's Law, Resistance, Series/Parallel Circuits, Power
- 💡 **Light** — Reflection, Refraction, Mirrors, Lenses, Snell's Law
- 👁️ **Human Eye** — Eye Structure, Vision Defects, Corrective Lenses

---

## ✨ Features

- **MCQ Quiz Engine** — Instant answer feedback on every question
- **Formula Rendering** — Physics equations beautifully rendered via KaTeX
- **Score Tracking** — Scores saved locally in the browser (localStorage)
- **Study Streak** — Tracks daily visits to keep motivation high
- **Smooth Animations** — Page transitions, particle background, scroll effects
- **Mobile Friendly** — Fully responsive layout with collapsible sidebar
- **Answer Explanations** — Detailed explanation shown after each answer

---

## 🛠️ Tech Stack

| Layer | Technology |
|---|---|
| Structure | HTML5 |
| Styling | CSS3 (Custom Properties, Flexbox, Grid) |
| Logic | Vanilla JavaScript ES6 |
| Math Rendering | KaTeX v0.16.9 |
| Fonts | Google Fonts (Space Mono, Crimson Pro) |
| Storage | Browser LocalStorage |

---

## 🌐 Browser Support

| Browser | Supported |
|---|---|
| Chrome 90+ | ✅ |
| Firefox 88+ | ✅ |
| Edge 90+ | ✅ |
| Safari 14+ | ✅ |

---

## 📸 App Pages

| Page | Description |
|---|---|
| Dashboard | Overview of chapters, scores, and streak |
| Chapter Quiz | MCQ questions with formula rendering |
| Results | Final score with retry option |

---

## 📄 License

Free to use for educational purposes.

---

<p align="center">Made with 💙 for Class 10 students</p>
